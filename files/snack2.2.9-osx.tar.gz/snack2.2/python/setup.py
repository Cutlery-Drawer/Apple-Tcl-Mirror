from distutils.core import setup

setup(name="tkSnack",
	version="2.2.9",
	description="Python interface to the Snack Sound Toolkit",
	url="http://www.speech.kth.se/snack/index.html",
	py_modules=['tkSnack'],
)

